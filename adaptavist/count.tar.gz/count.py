import sys
from collections import Counter

def word_count(file_path):
    with open(file_path, 'r') as file:
        words = file.read().split()
        word_counts = Counter(words)
        sorted_word_counts = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)

        for word, count in sorted_word_counts:
            print(f'{word}: {count}')

if __name__ == "__main__":
    word_count(sys.argv[1])
